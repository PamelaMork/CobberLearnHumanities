# Grimm Fairy Tales

Eighteen individual tales split from Grimms' Fairy Tales. This pack is expected to show stronger off-diagonal similarity because the documents share source, tradition, genre, translator style, and motif structure.

Texts in this pack: 18.
