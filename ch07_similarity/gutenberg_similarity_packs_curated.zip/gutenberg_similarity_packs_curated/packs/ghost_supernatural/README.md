# Ghost / Supernatural Stories

Eight supernatural/ghost texts, deduplicated to keep only one Christmas Carol and avoid obvious repeated editions.

Texts in this pack: 8.
