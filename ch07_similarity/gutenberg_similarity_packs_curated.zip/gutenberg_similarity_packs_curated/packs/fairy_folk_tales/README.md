# Fairy / Folk Tales

Ten fairy/folk-tale collections, intentionally including non-Western and non-Anglo material where available: Arabian Nights, Russian, Indian, Iroquois, Jewish, and Northern myth collections.

Texts in this pack: 10.
