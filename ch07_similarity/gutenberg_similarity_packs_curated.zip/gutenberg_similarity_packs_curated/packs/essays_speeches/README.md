# Essays / Speeches

Ten essay-like public-domain works chosen for variety in argument, reflection, social criticism, philosophy, and literary nonfiction.

Texts in this pack: 10.
