# Curated Gutenberg Similarity Packs

This folder contains classroom-ready text packs for the humanities similarity GUI.

## Format

Each pack has:

- `metadata.csv`
- `records.jsonl`
- `texts/*.txt`

Top-level files:

- `all_metadata.csv`
- `all_records.jsonl`

Recommended GUI input: read `all_records.jsonl` or each pack's `records.jsonl`.
Each record includes `doc_id`, `pack_key`, `pack_label`, `title`, `author`, `source_title`,
`gutenberg_id`, `gutenberg_url`, `text_file`, `word_count`, and `curation_note`.

## Packs

- `ghost_supernatural`: 8 texts
- `detective_mystery`: 8 texts
- `fairy_folk_tales`: 10 texts, including non-Western/non-Anglo material where available
- `grimm_fairy_tales`: 18 individual Grimm tales split from one source collection
- `essays_speeches`: 10 essay-like works

The `grimm_fairy_tales` pack is intentionally different from the mixed packs.
It should produce more off-diagonal similarity because the items share a common collection,
style, genre, and motif vocabulary.
